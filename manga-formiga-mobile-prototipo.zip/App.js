import React, { useMemo, useState } from "react";
import { SafeAreaView, View, Text, TextInput, ScrollView, Pressable, StyleSheet, Alert } from "react-native";
import { StatusBar } from "expo-status-bar";

const ITEMS = [
  {id:"banana", name:"Banana nanica", category:"Frutas", emoji:"🍌", unit:"kg", price:5.99, store:"Quitanda do Bairro"},
  {id:"maca", name:"Maçã Fuji", category:"Frutas", emoji:"🍎", unit:"kg", price:9.90, store:"Quitanda do Bairro"},
  {id:"laranja", name:"Laranja pera", category:"Frutas", emoji:"🍊", unit:"kg", price:4.79, store:"Horti Vale"},
  {id:"alface", name:"Alface crespa", category:"Verduras", emoji:"🥬", unit:"un", price:3.49, store:"Horti Vale"},
  {id:"tomate", name:"Tomate italiano", category:"Legumes", emoji:"🍅", unit:"kg", price:7.99, store:"Quitanda do Bairro"},
  {id:"cenoura", name:"Cenoura", category:"Legumes", emoji:"🥕", unit:"kg", price:4.99, store:"Horti Vale"},
  {id:"limao", name:"Limão tahiti", category:"Frutas", emoji:"🍋", unit:"kg", price:3.99, store:"Quitanda do Bairro"},
  {id:"couve", name:"Couve", category:"Verduras", emoji:"🌿", unit:"maço", price:3.79, store:"Horti Vale"},
];
const CATS = ["Tudo","Frutas","Verduras","Legumes"];
const brl = n => n.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});

export default function App() {
  const [category,setCategory] = useState("Tudo");
  const [query,setQuery] = useState("");
  const [cart,setCart] = useState({});
  const [tab,setTab] = useState("Início");
  const [address,setAddress] = useState("São José dos Campos, SP");
  const [showCheckout,setShowCheckout] = useState(false);

  const visible = useMemo(() => ITEMS.filter(p =>
    (category==="Tudo" || p.category===category) &&
    p.name.toLowerCase().includes(query.trim().toLowerCase())
  ),[category,query]);
  const count = Object.values(cart).reduce((s,n)=>s+n,0);
  const total = ITEMS.reduce((s,p)=>s+p.price*(cart[p.id]||0),0);
  const change = (id,delta) => setCart(old => {
    const next={...old}; next[id]=Math.max(0,(next[id]||0)+delta);
    if(!next[id]) delete next[id]; return next;
  });

  const submitOrder = () => {
    if(!count) return Alert.alert("Carrinho vazio","Adicione produtos antes de continuar.");
    Alert.alert("Pedido demonstrativo",`Seu pedido de ${brl(total)} foi preparado. A integração com pedidos reais e pagamento será adicionada na próxima etapa.`);
    setShowCheckout(false);
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar style="light"/>
      <View style={s.header}>
        <Text style={s.brand}>🥭 Manga Formiga</Text>
        <Text style={s.loc}>⌖ Entregando em</Text>
        <TextInput style={s.address} value={address} onChangeText={setAddress} placeholder="Informe seu endereço" placeholderTextColor="#d9e9d9"/>
        <View style={s.searchBox}><Text style={s.searchIcon}>⌕</Text><TextInput value={query} onChangeText={setQuery} placeholder="Buscar frutas, verduras, legumes..." placeholderTextColor="#7c897d" style={s.search}/></View>
      </View>
      <ScrollView contentContainerStyle={s.content}>
        {tab==="Início" ? <>
          <View style={s.banner}>
            <View style={{flex:1}}><Text style={s.bannerTitle}>Fresquinho até sua porta.</Text><Text style={s.bannerSub}>Da quitanda para sua casa. Fresquinho de verdade!</Text></View>
            <Text style={{fontSize:48}}>🥬🍊</Text>
          </View>
          <Text style={s.sectionTitle}>Comprar por categoria</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.categories}>
            {CATS.map(c=><Pressable key={c} onPress={()=>setCategory(c)} style={[s.category,category===c&&s.categoryActive]}><Text style={[s.categoryText,category===c&&s.categoryTextActive]}>{c}</Text></Pressable>)}
          </ScrollView>
          <View style={s.sectionRow}><Text style={s.sectionTitle}>Fresquinhos do dia</Text><Text style={s.smallMuted}>{visible.length} produtos</Text></View>
          <View style={s.grid}>
            {visible.map(p=><View key={p.id} style={s.card}>
              <View style={s.productPic}><Text style={{fontSize:48}}>{p.emoji}</Text></View>
              <Text style={s.storeName}>{p.store}</Text>
              <Text style={s.productName}>{p.name}</Text>
              <Text style={s.unit}>Por {p.unit}</Text>
              <View style={s.priceRow}><Text style={s.price}>{brl(p.price)}</Text>
                <Pressable onPress={()=>change(p.id,1)} style={s.add}><Text style={s.addText}>+</Text></Pressable>
              </View>
              {!!cart[p.id]&&<View style={s.qtyRow}><Pressable onPress={()=>change(p.id,-1)} style={s.qtyBtn}><Text>−</Text></Pressable><Text style={s.qty}>{cart[p.id]} no carrinho</Text><Pressable onPress={()=>change(p.id,1)} style={s.qtyBtn}><Text>+</Text></Pressable></View>}
            </View>)}
          </View>
          {visible.length===0&&<Text style={s.empty}>Não encontramos produtos com essa busca.</Text>}
        </> : tab==="Pedidos" ? <View style={s.infoCard}><Text style={s.sectionTitle}>Seus pedidos</Text><Text style={s.muted}>Seus pedidos aparecerão aqui depois que a plataforma estiver conectada ao banco de dados.</Text></View> :
          <View style={s.infoCard}><Text style={s.sectionTitle}>Minha conta</Text><Text style={s.muted}>Cadastro, login e endereços serão conectados na próxima etapa.</Text><Text style={s.profileLabel}>Endereço de entrega</Text><TextInput value={address} onChangeText={setAddress} style={s.profileInput}/></View>}
      </ScrollView>
      {count>0&&<Pressable style={s.cartBar} onPress={()=>setShowCheckout(v=>!v)}><View><Text style={s.cartTitle}>🛒 Ver carrinho · {count} {count===1?"item":"itens"}</Text><Text style={s.cartSub}>Entrega feita pela própria quitanda</Text></View><Text style={s.cartTotal}>{brl(total)}　›</Text></Pressable>}
      {showCheckout&&<View style={s.checkout}>
        <View style={s.sectionRow}><Text style={s.sectionTitle}>Resumo do carrinho</Text><Pressable onPress={()=>setShowCheckout(false)}><Text style={s.close}>Fechar</Text></Pressable></View>
        {ITEMS.filter(p=>cart[p.id]).map(p=><View key={p.id} style={s.checkoutLine}><Text style={s.muted}>{p.emoji} {p.name} × {cart[p.id]}</Text><Text style={s.muted}>{brl(p.price*cart[p.id])}</Text></View>)}
        <View style={s.checkoutLine}><Text style={s.totalLabel}>Total estimado</Text><Text style={s.totalLabel}>{brl(total)}</Text></View>
        <Text style={s.muted}>A quitanda confirmará disponibilidade, taxa e horário de entrega.</Text>
        <Pressable style={s.checkoutBtn} onPress={submitOrder}><Text style={s.checkoutBtnText}>Continuar pedido</Text></Pressable>
      </View>}
      <View style={s.bottomNav}>
        {["Início","Pedidos","Minha conta"].map(t=><Pressable key={t} onPress={()=>{setTab(t);setShowCheckout(false)}} style={s.navItem}><Text style={[s.navText,tab===t&&s.navActive]}>{t==="Início"?"⌂":t==="Pedidos"?"▤":"♙"}{"\n"}{t}</Text></Pressable>)}
      </View>
    </SafeAreaView>
  );
}

const s=StyleSheet.create({
 safe:{flex:1,backgroundColor:"#f7f8f2"},header:{backgroundColor:"#1d603b",paddingHorizontal:18,paddingTop:12,paddingBottom:17},
 brand:{color:"#fff",fontSize:23,fontWeight:"900",marginBottom:10},loc:{color:"#d9eadb",fontSize:12},address:{color:"#fff",fontSize:14,fontWeight:"700",paddingVertical:3},
 searchBox:{marginTop:14,backgroundColor:"#fff",borderRadius:12,flexDirection:"row",alignItems:"center",paddingHorizontal:11},searchIcon:{fontSize:23,color:"#6b786b"},search:{flex:1,height:43,color:"#213c2b",fontSize:13},
 content:{padding:15,paddingBottom:100},banner:{backgroundColor:"#e5f0ce",borderRadius:17,padding:16,flexDirection:"row",alignItems:"center",marginBottom:14},bannerTitle:{fontSize:22,fontWeight:"900",color:"#245436",maxWidth:210},bannerSub:{fontSize:12,color:"#4e6b50",marginTop:6,maxWidth:205},
 sectionTitle:{fontSize:17,fontWeight:"800",color:"#203629",marginTop:5,marginBottom:10},categories:{gap:8,paddingBottom:13},category:{borderWidth:1,borderColor:"#dce5d8",borderRadius:25,paddingHorizontal:14,paddingVertical:9,backgroundColor:"#fff"},categoryActive:{backgroundColor:"#24643c",borderColor:"#24643c"},categoryText:{fontSize:12,color:"#34523d",fontWeight:"600"},categoryTextActive:{color:"#fff"},
 sectionRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between"},smallMuted:{fontSize:11,color:"#778475"},grid:{flexDirection:"row",flexWrap:"wrap",gap:10},card:{width:"48.2%",backgroundColor:"#fff",borderRadius:15,borderWidth:1,borderColor:"#e7ebdf",padding:10},productPic:{height:98,backgroundColor:"#f1f5e9",borderRadius:11,alignItems:"center",justifyContent:"center",marginBottom:8},storeName:{fontSize:10,color:"#6d856b",marginBottom:3},productName:{fontSize:14,fontWeight:"800",color:"#203629"},unit:{fontSize:11,color:"#778477",marginTop:3},priceRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:8},price:{fontSize:15,fontWeight:"900",color:"#245436"},add:{width:31,height:31,borderRadius:10,backgroundColor:"#21643b",alignItems:"center",justifyContent:"center"},addText:{color:"#fff",fontSize:22,fontWeight:"600",marginTop:-2},qtyRow:{flexDirection:"row",alignItems:"center",justifyContent:"space-between",marginTop:7},qtyBtn:{width:27,height:26,borderRadius:8,backgroundColor:"#e8f1df",alignItems:"center",justifyContent:"center"},qty:{fontSize:10,color:"#526553"},empty:{textAlign:"center",padding:25,color:"#718071"},
 cartBar:{position:"absolute",bottom:61,left:14,right:14,backgroundColor:"#1e6039",borderRadius:14,paddingHorizontal:15,paddingVertical:12,flexDirection:"row",justifyContent:"space-between",alignItems:"center",elevation:5},cartTitle:{fontSize:14,fontWeight:"800",color:"#fff"},cartSub:{fontSize:10,color:"#d7e8d9",marginTop:3},cartTotal:{fontSize:14,fontWeight:"900",color:"#fff"},
 checkout:{position:"absolute",left:12,right:12,bottom:112,backgroundColor:"#fff",borderRadius:16,padding:15,borderWidth:1,borderColor:"#dfe7d9",elevation:7},checkoutLine:{flexDirection:"row",justifyContent:"space-between",marginVertical:6},totalLabel:{fontWeight:"900",color:"#203629",marginTop:7},checkoutBtn:{backgroundColor:"#21643b",borderRadius:11,padding:13,alignItems:"center",marginTop:10},checkoutBtnText:{color:"#fff",fontWeight:"800"},close:{color:"#357348",fontWeight:"700"},muted:{fontSize:12,color:"#728071",lineHeight:18},infoCard:{backgroundColor:"#fff",padding:17,borderRadius:16},profileLabel:{fontSize:12,fontWeight:"700",marginTop:15,color:"#35553d"},profileInput:{borderWidth:1,borderColor:"#dfe7d9",borderRadius:10,padding:11,marginTop:5,color:"#203629"},
 bottomNav:{position:"absolute",bottom:0,left:0,right:0,backgroundColor:"#fff",borderTopWidth:1,borderTopColor:"#e5e9df",height:60,flexDirection:"row",justifyContent:"space-around",alignItems:"center"},navItem:{alignItems:"center",flex:1},navText:{fontSize:10,color:"#778477",textAlign:"center",lineHeight:16},navActive:{color:"#21643b",fontWeight:"900"}
});
