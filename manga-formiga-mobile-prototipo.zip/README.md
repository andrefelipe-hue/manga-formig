# Manga Formiga — protótipo mobile

Este é um protótipo inicial em Expo/React Native para Android e iOS.

## Inclui
- Catálogo demonstrativo de frutas, verduras e legumes
- Busca e filtros por categoria
- Carrinho com quantidades e total
- Aba de pedidos e conta (placeholders)
- Campo para endereço
- Fluxo de pedido demonstrativo

**Importante:** ainda não há autenticação, banco de dados, pagamento, estoque sincronizado, pedido real nem painel de parceiros. Os produtos, preços e quitandas são exemplos.

## Como rodar
1. Instale Node.js LTS em um computador.
2. Extraia este ZIP e abra o terminal dentro da pasta.
3. Rode `npm install`.
4. Rode `npx expo start`.
5. Instale Expo Go no telefone e escaneie o QR Code na mesma rede Wi-Fi.

Ajustes para publicação exigem ambiente de build Expo/EAS e contas de desenvolvedor.
